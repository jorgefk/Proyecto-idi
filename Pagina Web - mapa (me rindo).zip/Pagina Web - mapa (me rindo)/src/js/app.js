document.addEventListener("DOMContentLoaded", function(){
    iniciarApp();
});

function iniciarApp() {
ocultar1();
ocultar2();
ocultar3();

};

function mostrar1(){

    document.getElementById("info-planta1").style.display = "inline-block";
};
function mostrar2(){

    document.getElementById("info-planta2").style.display = "inline-block";
};
function mostrar3(){

    document.getElementById("info-planta3").style.display = "inline-block";
};

function ocultar1(){
    document.getElementById("info-planta1").style.display = "none";
};
function ocultar2(){
    document.getElementById("info-planta2").style.display = "none";
};
function ocultar3(){
    document.getElementById("info-planta3").style.display = "none";
};