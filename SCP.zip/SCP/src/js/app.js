document.addEventListener("DOMContentLoaded", function(){
    iniciarApp();
});

function iniciarApp() {

};



// const tarjeta = innerHTML = ;
