
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Varela&display=swap" rel="stylesheet">
    <title>Sistema de Control de Plantas</title>
    <link rel="stylesheet" href="build/css/app.css">


</head>
<body>
    <header class="header">
        <div class="contenedor contenido-header">
            <h1>Sistema de Control de Plantas</h1>

            <nav class="navegacion-principal">
                <a href="#"> Cuidado de plantas</a>
                <a href="#">Colegio</a>
                <a href="#">Nosotros</a>
            </nav>
        </div>
    </header>
    <main class="contenedor main-bloques">
        <section class="bloque-planta">
            <div class="bloque__bg bg-bien">
                <picture>
                    <source srcset="build/img/aloe.avif" type="image/avif">
                    <source srcset="build/img/aloe.webp" type="image/webp">
                    <source srcset="build/img/aloe.jpg" type="image/jpg">

                    <img loading="lazy" width="200" height="300" src="build/img/aloe.jpg" alt="">
                </picture>
                <div class="bloque-planta__nombre">
                        <h2 id="nombre-planta1"></h2>
                    </div>
            </div>
            <div class="bloque__info bloque-g1">
                <div class="info__1">
                    <h3 id="humedad-b1">Humedad: </h3>
                    <h3 id="luz-b1">Luz solar/hs: 3</h3>    
                </div>
                <div class="info__2">
                    <h3>Ambiente: Humedo</h3>
                </div>
                <div class="info__3">
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo, ratione quia veritatis voluptatem</p>
                </div>
            </div>

        </section>

        <section class="bloque-planta bloque-g2">
            <div class="bloque__bg bg-critico">
                <picture>
                    <source srcset="build/img/helecho.avif" type="image/avif">
                    <source srcset="build/img/helecho.webp" type="image/webp">
                    <source srcset="build/img/helecho.jpg" type="image/jpg">

                    <img loading="lazy" width="200" height="300" src="build/img/helecho.jpg" alt="">
                </picture>
                <div class="bloque-planta__nombre">
                        <h2 id="nombre-planta2"></h2>
                    </div>
            </div>
            <div class="bloque__info">
                <div class="info__1">
                    <h3 id="humedad-b2">Humedad: 5</h3>
                    <h3  id="luz-b2">Luz solar/hs: 3</h3>    
                </div>
                <div class="info__2">
                    <h3>Ambiente: Humedo</h3>
                </div>
                <div class="info__3">
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo, ratione quia veritatis voluptatem</p>
                </div>
            </div>
        </section>

        <section class="bloque-planta bloque-g3">
            <div class="bloque__bg bg-regular">
                <picture class="bloque_planta__img">
                    <source srcset="build/img/orquidea_rosa.avif" type="image/avif">
                    <source srcset="build/img/orquidea_rosa.webp" type="image/webp">
                    <source srcset="build/img/orquidea_rosa.jpg" type="image/jpg">

                    <img loading="lazy" width="200" height="300" src="build/img/orquidea_rosa.jpg" alt="">
                    
                </picture>
                <div class="bloque-planta__nombre">
                        <h2 id="nombre-planta3"></h2>
                    </div>
            </div>
                <div class="bloque__info">
                    <div class="info__1">
                        <h3 id="humedad-b3">Humedad: 5</h3>
                        <h3 id="luz-b3">Luz solar/hs: 3</h3>    
                    </div>
                    <div class="info__2">
                        <h3>Ambiente: Humedo</h3>
                    </div>
                    <div class="info__3">
                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo, ratione quia veritatis voluptatem</p>
                    </div>
            </div>

        </section>

        <div class="cargaDePlanta">
            <h3>Agregar nueva Planta</h3>
            <form action="https://127.0.0.1/backend_idi/subirPlanta.php">
                <div class="cargaDePlanta__form__b1">
                    <label for="nombre">Nombre de planta</label>
                </div>
                    <input type="text" id="nombre" name="nombre" placeholder="Orquidea..." class="input-value">

                <div class="cargaDePlanta__form__b2">
                    <label for="ubicacion">Ubicacion de la planta</label>
                </div>
                    <input type="text" id="ubicacion" name="ubicacion" placeholder="Comedor..." class="input-value">

                <input type="submit" class="cargaDePlanta__submit">
            </form> 
        </div>
        <script src="/SCP/build/js/app.js"></script>
    </main>


    <!-- <form action="https://127.0.0.1/backend_idi/update.php" 
    method="get">

        <input type="submit"  value="consultar">
    </form> -->

    
    <div id="estado"></div>
    <div id="estado2"></div>
    <script>

        async function ajax() {
            const http = new XMLHttpRequest();
            const url = 'http://127.0.0.1/backend_idi/update.php';

            http.onreadystatechange = function (){
                if(this.readyState == 4 && this.status == 200) {
                    // console.log(this.responseText);
                    // console.log("hasta aca funciona");

                    document.getElementById("estado").innerHTML = this.responseText
                }
            }

            http.open("GET", url);
            http.send();
        }
    
    setInterval(function() {
        ajax();
    }, 300)

    async function ajax2() {
            const http = new XMLHttpRequest();
            const url = 'http://127.0.0.1/backend_idi/1er-nombre-bloque.php';

            http.onreadystatechange = function (){
                if(this.readyState == 4 && this.status == 200) {
                    console.log(this.responseText);
                    console.log("hasta aca funciona");

                    document.getElementById("nombre-planta1").innerHTML = this.responseText
                }
            }

            http.open("GET", url);
            http.send();
        }
    
    setInterval(function() {
        ajax2();
    }, 300)

    async function ajax3() {
            const http = new XMLHttpRequest();
            const url = 'http://127.0.0.1/backend_idi/2do-nombre-bloque.php';

            http.onreadystatechange = function (){
                if(this.readyState == 4 && this.status == 200) {
                    console.log(this.responseText);
                    console.log("hasta aca funciona");

                    document.getElementById("nombre-planta2").innerHTML = this.responseText
                }
            }

            http.open("GET", url);
            http.send();
        }
    
    setInterval(function() {
        ajax3();
    }, 300)

    async function ajax4() {
            const http = new XMLHttpRequest();
            const url = 'http://127.0.0.1/backend_idi/3er-nombre-bloque.php';

            http.onreadystatechange = function (){
                if(this.readyState == 4 && this.status == 200) {
                    console.log(this.responseText);
                    console.log("hasta aca funciona");

                    document.getElementById("nombre-planta3").innerHTML = this.responseText
                }
            }

            http.open("GET", url);
            http.send();
        }
    
    setInterval(function() {
        ajax4();
    }, 300)

    async function aj_humedad1() {
            const http = new XMLHttpRequest();
            const url = 'http://127.0.0.1/backend_idi/1-humedad-b.php';

            http.onreadystatechange = function (){
                if(this.readyState == 4 && this.status == 200) {
                    console.log(this.responseText);
                    console.log("hasta aca funciona");

                    document.getElementById("humedad-b1").innerHTML = this.responseText
                }
            }

            http.open("GET", url);
            http.send();
        }
    
    setInterval(function() {
        aj_humedad1();
    }, 300)

    async function aj_humedad2() {
            const http = new XMLHttpRequest();
            const url = 'http://127.0.0.1/backend_idi/2-humedad-b.php';

            http.onreadystatechange = function (){
                if(this.readyState == 4 && this.status == 200) {
                    console.log(this.responseText);
                    console.log("hasta aca funciona");

                    document.getElementById("humedad-b2").innerHTML = this.responseText
                }
            }

            http.open("GET", url);
            http.send();
        }
    
    setInterval(function() {
        aj_humedad2();
    }, 300)

    async function aj_humedad3() {
            const http = new XMLHttpRequest();
            const url = 'http://127.0.0.1/backend_idi/3-humedad-b.php';

            http.onreadystatechange = function (){
                if(this.readyState == 4 && this.status == 200) {
                    console.log(this.responseText);
                    console.log("hasta aca funciona");

                    document.getElementById("humedad-b3").innerHTML = this.responseText
                }
            }

            http.open("GET", url);
            http.send();
        }
    
    setInterval(function() {
        aj_humedad3();
    }, 300)

    async function aj_luz1() {
            const http = new XMLHttpRequest();
            const url = 'http://127.0.0.1/backend_idi/1-luz-b.php';

            http.onreadystatechange = function (){
                if(this.readyState == 4 && this.status == 200) {
                    console.log(this.responseText);
                    console.log("hasta aca funciona");

                    document.getElementById("luz-b1").innerHTML = this.responseText
                }
            }

            http.open("GET", url);
            http.send();
        }
    
    setInterval(function() {
        aj_luz1();
    }, 300)

    async function aj_luz2() {
            const http = new XMLHttpRequest();
            const url = 'http://127.0.0.1/backend_idi/2-luz-b.php';

            http.onreadystatechange = function (){
                if(this.readyState == 4 && this.status == 200) {
                    console.log(this.responseText);
                    console.log("hasta aca funciona");

                    document.getElementById("luz-b2").innerHTML = this.responseText
                }
            }

            http.open("GET", url);
            http.send();
        }
    
    setInterval(function() {
        aj_luz2();
    }, 300)

    async function aj_luz3() {
            const http = new XMLHttpRequest();
            const url = 'http://127.0.0.1/backend_idi/3-luz-b.php';

            http.onreadystatechange = function (){
                if(this.readyState == 4 && this.status == 200) {
                    console.log(this.responseText);
                    console.log("hasta aca funciona");

                    document.getElementById("luz-b3").innerHTML = this.responseText
                }
            }

            http.open("GET", url);
            http.send();
        }
    
    setInterval(function() {
        aj_luz3();
    }, 300)
    </script>

    </script>
    
        



<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
</body>
</html>